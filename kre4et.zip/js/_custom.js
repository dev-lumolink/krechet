$(function() {
    $('[data-slider="first-screen"]').owlCarousel({
        items: 1,
        nav: true,
        autoplay: true
    });
});